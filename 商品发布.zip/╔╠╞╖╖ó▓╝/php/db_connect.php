<?php
// 数据库配置信息（基础配置，适配XAMPP默认设置）
$servername = "localhost"; // 服务器地址
$username = "root"; // 数据库用户名（XAMPP默认）
$password = ""; // 数据库密码（XAMPP默认为空）
$dbname = "campus_secondhand"; // 数据库名

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 设置字符编码，避免中文乱码
$conn->set_charset("utf8");
?>