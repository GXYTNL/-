<?php
header("Content-type: text/html; charset=utf-8");
include 'db_connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // 简单的防注入处理，确保ID是整数
    $id = intval($id);

    $sql = "DELETE FROM goods WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('商品删除成功！'); window.location.href='../goods_list.php';</script>";
    } else {
        echo "<script>alert('删除失败：" . $conn->error . "'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('参数错误'); window.history.back();</script>";
}

$conn->close();
?>
