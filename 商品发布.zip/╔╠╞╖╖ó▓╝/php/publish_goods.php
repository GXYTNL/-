<?php
// 引入数据库连接文件
include 'db_connect.php';

// 检查是否为POST请求（防止直接访问）
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取表单数据并过滤（防止XSS攻击）
    $name = htmlspecialchars($_POST['name']);
    $price = floatval($_POST['price']);
    $description = htmlspecialchars($_POST['description']);
    $seller = htmlspecialchars($_POST['seller']);
    $contact = htmlspecialchars($_POST['contact']);

    // 处理图片上传
    $image_path = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../uploads/";
        // 确保目录存在
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
        // 生成唯一文件名防止覆盖
        $new_filename = uniqid() . "." . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        // 允许的文件类型
        $allowed_types = array("jpg", "jpeg", "png", "gif");
        if (in_array(strtolower($file_extension), $allowed_types)) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                // 数据库存储相对路径
                $image_path = "uploads/" . $new_filename;
            } else {
                echo "图片上传失败";
                exit;
            }
        } else {
            echo "只允许上传 JPG, JPEG, PNG, GIF 格式的图片";
            exit;
        }
    }

    // 准备SQL语句（预处理，防止SQL注入）
    // 注意：这里假设数据库已经添加了 image 字段
    $sql = "INSERT INTO goods (name, price, description, seller, contact, image) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdssss", $name, $price, $description, $seller, $contact, $image_path);

    // 执行SQL语句并判断结果
    if ($stmt->execute()) {
        // 发布成功，重定向到商品列表页
        header("Location: ../goods_list.php");
        exit();
    } else {
        echo "发布失败: " . $stmt->error;
    }

    // 关闭预处理语句和连接
    $stmt->close();
    $conn->close();
} else {
    // 非POST请求，重定向到发布页面
    header("Location: ../publish.html");
    exit();
}
?>
