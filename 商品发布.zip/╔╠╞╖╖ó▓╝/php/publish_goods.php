<?php
// 引入数据库连接文件
include 'db_connect.php';

// 检查是否为POST请求（防止直接访问）
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取表单数据并过滤（防止XSS攻击）
    $name = htmlspecialchars($_POST['name']);
    $price = floatval($_POST['price']);
    $description = htmlspecialchars($_POST['description']);
    $seller = htmlspecialchars($_POST['seller']);
    $contact = htmlspecialchars($_POST['contact']);

    // 准备SQL语句（预处理，防止SQL注入）
    $sql = "INSERT INTO goods (name, price, description, seller, contact) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdsss", $name, $price, $description, $seller, $contact);

    // 执行SQL语句并判断结果
    if ($stmt->execute()) {
        // 发布成功，重定向到商品列表页
        header("Location: ../goods_list.php");
        exit();
    } else {
        echo "发布失败: " . $stmt->error;
    }

    // 关闭预处理语句和连接
    $stmt->close();
    $conn->close();
} else {
    // 非POST请求，重定向到发布页面
    header("Location: ../publish.html");
    exit();
}
?>