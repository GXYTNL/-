<?php
include 'db_connect.php';

// Check if the image column exists
$check_sql = "SHOW COLUMNS FROM goods LIKE 'image'";
$result = $conn->query($check_sql);

if ($result->num_rows == 0) {
    // Column doesn't exist, add it
    $sql = "ALTER TABLE goods ADD COLUMN image VARCHAR(255) DEFAULT NULL";
    if ($conn->query($sql) === TRUE) {
        echo "Table 'goods' updated successfully: 'image' column added.";
    } else {
        echo "Error updating table: " . $conn->error;
    }
} else {
    echo "'image' column already exists in 'goods' table.";
}

$conn->close();
?>
