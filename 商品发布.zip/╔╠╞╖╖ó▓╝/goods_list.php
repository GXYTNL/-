<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>商品列表 - 校园二手物品交易平台</title>
    <!-- 引入 Font Awesome 图标库 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar">
        <div class="container">
            <h1 class="logo">校园二手交易平台</h1>
            <div class="nav-links">
                <a href="index.html">首页</a>
                <a href="goods_list.php" class="active">商品列表</a>
                <a href="publish.html" class="publish-btn">发布商品</a>
            </div>
        </div>
    </nav>

    <!-- 商品列表 -->
    <section class="goods-list">
        <div class="container">
            <h3>二手商品列表</h3>
            <div class="goods-cards">
                <?php
                // 引入数据库连接文件
                include 'php/db_connect.php';

                // 查询所有商品（按发布时间倒序）
                $sql = "SELECT * FROM goods ORDER BY time DESC";
                $result = $conn->query($sql);

                // 判断是否有商品
                if ($result->num_rows > 0) {
                    // 循环输出商品信息
                    while($row = $result->fetch_assoc()) {
                        $image_html = '';
                        if (!empty($row["image"]) && file_exists($row["image"])) {
                            $image_html = '<div class="goods-img"><img src="'.$row["image"].'" alt="'.$row["name"].'"></div>';
                        } else {
                            $image_html = '<div class="goods-img"><img src="https://via.placeholder.com/300x200?text=No+Image" alt="暂无图片"></div>';
                        }
                        
                        echo '
                        <div class="goods-card">
                            '.$image_html.'
                            <h4>'.$row["name"].'</h4>
                            <p class="price">¥'.$row["price"].'</p>
                            <p class="desc">'.$row["description"].'</p>
                            <p class="seller-info">卖家：'.$row["seller"].' | 联系方式：'.$row["contact"].'</p>
                            <p class="seller-info">发布时间：'.$row["time"].'</p>
                            <div class="card-actions">
                                <a href="goods_detail.php?id='.$row["id"].'" class="detail-btn">
                                    <i class="fas fa-eye"></i> 查看详情
                                </a>
                                <a href="php/delete_goods.php?id='.$row["id"].'" class="delete-btn" onclick="return confirm(\'确定要删除这个商品吗？\');">
                                    <i class="fas fa-trash-alt"></i> 删除
                                </a>
                            </div>
                        </div>
                        ';
                    }
                } else {
                    // 无商品时的提示
                    echo '<div style="grid-column: 1 / -1; text-align: center; color: #666; font-size: 18px;">暂无商品，快来发布你的第一件二手物品吧！</div>';
                }

                // 关闭数据库连接
                $conn->close();
                ?>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>© 2025 校园二手物品交易平台 - 所有权利保留</p>
        </div>
    </footer>
</body>
</html>